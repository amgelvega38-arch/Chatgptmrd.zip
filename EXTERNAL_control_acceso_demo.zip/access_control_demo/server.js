// Demo independiente de control de acceso. No está integrado con el proyecto iOS.
// Node 18+: npm install express; ADMIN_TOKEN=... node server.js
const express = require('express');
const crypto = require('crypto');
const app = express();
app.use(express.json());
app.use(express.static('public'));
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;
if (!ADMIN_TOKEN) throw new Error('Define ADMIN_TOKEN antes de iniciar.');
const keys = new Map(); // DEMO: reemplazar por base de datos persistente en producción.
const sessions = new Map();
const hash = s => crypto.createHash('sha256').update(s).digest('hex');
function admin(req,res,next){ if(req.get('authorization') !== `Bearer ${ADMIN_TOKEN}`) return res.sendStatus(403); next(); }
function revokeKey(key, state){ const k=hash(key); const row=keys.get(k)||{status:'active',generation:0}; row.status=state; row.generation++; keys.set(k,row); for(const [token,s] of sessions) if(s.keyHash===k) sessions.delete(token); }
app.post('/admin/seed',admin,(req,res)=>{const {key}=req.body||{}; if(!key) return res.status(400).json({error:'key requerida'}); keys.set(hash(key),{status:'active',generation:0}); res.json({ok:true});});
app.post('/admin/ban',admin,(req,res)=>{const {key}=req.body||{}; if(!key) return res.sendStatus(400); revokeKey(key,'banned'); res.json({ok:true,revoked:true});});
app.post('/admin/reset',admin,(req,res)=>{const {key}=req.body||{}; if(!key) return res.sendStatus(400); revokeKey(key,'reset'); res.json({ok:true,revoked:true});});
app.post('/login',(req,res)=>{const {key}=req.body||{}; if(!key) return res.status(400).json({error:'KEY_REQUIRED'}); const k=hash(key), row=keys.get(k); if(!row) return res.status(401).json({error:'KEY_INVALID'}); if(row.status==='banned') return res.status(403).json({error:'KEY_BANNED'}); if(row.status!=='active') return res.status(403).json({error:'KEY_RESET'}); const token=crypto.randomBytes(32).toString('hex'); sessions.set(token,{keyHash:k,generation:row.generation}); res.json({token});});
app.get('/session',(req,res)=>{const token=req.get('authorization')?.replace(/^Bearer /,''); const s=sessions.get(token); if(!s) return res.status(401).json({active:false,reason:'REVOKED'}); const row=keys.get(s.keyHash); if(!row||row.status!=='active'||row.generation!==s.generation){sessions.delete(token);return res.status(401).json({active:false,reason:row?.status==='banned'?'KEY_BANNED':'KEY_RESET'});} res.json({active:true});});
app.listen(process.env.PORT||3000,()=>console.log('Access demo listening on port '+(process.env.PORT||3000)));
