# Demo independiente: control de acceso por sesión

Este paquete es una demostración genérica, separada del proyecto iOS y sin integración con funciones de modificación de juegos.

## Qué hace
- Renombra el ejemplo visual como `PECHO ALTO + CUELLO AVATAR`? **No**: el nombre de ese botón pertenece a la interfaz original; este demo no altera ni se conecta a ella.
- El administrador puede dar de baja una key (`/admin/ban`) o resetearla (`/admin/reset`).
- Las sesiones asociadas se revocan inmediatamente en el servidor. El cliente consulta `/session` cada 3 segundos y vuelve a pedir la key si la sesión ya no existe.

## Ejecutar
1. Instala Node.js 18 o posterior.
2. En esta carpeta ejecuta `npm install`.
3. Define un secreto: `export ADMIN_TOKEN='cambia-esto-por-un-secreto-largo'`.
4. Ejecuta `npm start` y abre `http://localhost:3000`.

## Administración (ejemplos)
Crear una key de prueba:
`curl -X POST http://localhost:3000/admin/seed -H 'Authorization: Bearer TU_SECRETO' -H 'Content-Type: application/json' -d '{"key":"DEMO-123"}'`

Ban:
`curl -X POST http://localhost:3000/admin/ban -H 'Authorization: Bearer TU_SECRETO' -H 'Content-Type: application/json' -d '{"key":"DEMO-123"}'`

Reset:
`curl -X POST http://localhost:3000/admin/reset -H 'Authorization: Bearer TU_SECRETO' -H 'Content-Type: application/json' -d '{"key":"DEMO-123"}'`

## Importante
Es una demo en memoria: reiniciar el proceso borra keys y sesiones. Para producción usa una base de datos persistente, HTTPS, límites de intentos, registros de auditoría y almacenamiento seguro de secretos. No subas el secreto al repositorio. No se ha compilado ni probado en un servidor de producción.
